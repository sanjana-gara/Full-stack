export default function Settings() {
  return (
    <div className="p-6 text-white">
      <h2 className="text-2xl font-bold">Settings Page</h2>
      <p>This is the admin settings page content.</p>
    </div>
  );
}
